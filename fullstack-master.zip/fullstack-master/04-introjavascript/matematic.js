

// Operadores matemáticos
// + - * / % 
let numUno = 50;
let numDos = 10;

let resultado;
/* let resultadoSuma;
let resultadoResta;
let resultadoDivision;
let resultadoMultiplicacion; */

resultado = numUno + numDos;

console.log(20 + 50);

console.log(numUno + numDos);

console.log("El resultado de la suma es: " + resultado);

console.log('======================================');

console.log(resultado);

console.log('======================================');

resultado = numUno - numDos;

// el signo + se utiliza para concatenar dotos de tipo string
console.log("El resultado de la resta es: " + resultado);

console.log('====================================');


//alert("El resultado de la resta es: " + resultado);

//Resta
resultado = numUno * numDos;

console.log("El resultado de la multiplicación es: " + resultado);


console.log('====================================');

resultado = numUno / numDos;

console.log("El resultado de la división es: " + resultado);

console.log('====================================');

resultado = numUno % numDos;

console.log("El resultado del módulo es: " + resultado);

console.log('====================================');

//Ejemplo de lenguaje estático
//java - C++ - C# - Kotlin - Swift - TypeScript => Programación Orientada Objetos
//int edad = 20;
//typescript
//edad: number = 15;

edad = '50'
edad = 50;

let uno = 50;
uno= 'pepe'
uno = true;




