

//estos son los comentarios de una sóla líena en javascript

/*
Cometarios 
de 
varias 
lineas
en JS
*/

//let hola = 'pepe'

/*
let hola = 'pepe'
let hola = 'pepe'
let hola = 'pepe'
let hola = 'pepe'
let hola = 'pepe'
let hola = 'pepe'
let hola = 'pepe'
let hola = 'pepe'
let hola = 'pepe'
*/

console.log('3. Estoy en el archivo de JS');
//Variables: espacios de memoria para almacenar datos
//1. con var
// palabras reservadas: son utilizadas sólo para las definiciones del lenguaje de programación
var nombre; //caracter/letras
var email// numeros
var edad;
var pais

//no
/*
var 12315;
var nombre apellido;
var =pais; 
var -edad
var nombre-apellido;
*/

//Si
var $provincia;
var _nombre;
var nombre_apellido; //underscore
var nombreApellidoPersona; //camelcase

let provincia;

//const representa una constante: no cambia en la ejecución del programa

//esto es una declaración de una variable y asignación de un valor
const DNI = 12345678;

nombre = 'Juan'; //string
apellido = 'Perez';

// = representa asignación de datos

provincia = 'Buenos Aires';  //string

provincia = "CABA"

provincia = 'Córdoba';

provincia = 15; //numeros - int 

provincia = true; //boolean

provincia  = false

//funciones
console.log(nombre + apellido + provincia)
console.info(nombre + apellido + provincia)
console.error(nombre + apellido + provincia)
console.warn(nombre + apellido + provincia)


//alert('Soy un mensaje de alerta al ususario') //ventana emergente


//DNI = 'Pepe'; //error en tiempo de ejecución






