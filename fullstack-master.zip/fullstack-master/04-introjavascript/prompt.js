

// El usuario nos proporciona los valores de los números

alert('Hola, vamos a sumar dos números!');



// el prompt es una función que nos permite pedirle al usuario que ingrese un valor


let numeroUnoDelUsuario = prompt('Ingresa el primer número: ');

console.log('El número del user es ' + numeroUnoDelUsuario);


let confirmacion = confirm('El número que ingresaste es ' + numeroUnoDelUsuario + ', ¿es correcto?');

console.log('La confirmación del usuario es ' + confirmacion);